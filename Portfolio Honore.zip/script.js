const videos = [
  { id: 'yvzLHXqcanQ' },
  { id: 'glsbQJfo4T8' },
  { id: '8_UyFSrQblc' },
  { id: 'jPFDwkthyaA' },
];

// Global state for chat personalization and memory
let chatState = {
  userRole: null, // 'teacher', 'student', 'collaborator', or null
  uploadedDocuments: [],
  conversationLength: 0
};

const videoGrid = document.getElementById('video-grid');
const ytPlayer = document.getElementById('yt-player');
const nowPlaying = document.getElementById('now-playing');

function setNowPlaying(title) {
  if (nowPlaying) nowPlaying.textContent = `Now Playing: ${title}`;
}

async function fetchTitle(videoId) {
  try {
    const url = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('oEmbed fetch failed');
    const data = await response.json();
    return data.title;
  } catch {
    return 'Ministry Video';
  }
}

function createCard(video) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'video-card';
  button.dataset.videoId = video.id;
  button.setAttribute('aria-label', 'Play video');

  const thumb = document.createElement('div');
  thumb.className = 'video-thumb';
  thumb.style.backgroundImage = `url('https://img.youtube.com/vi/${video.id}/hqdefault.jpg')`;

  const meta = document.createElement('div');
  meta.className = 'video-meta';
  meta.innerHTML = `
    <span class="video-title">Loading title…</span>
    <span class="video-desc">Click to play</span>
  `;

  button.appendChild(thumb);
  button.appendChild(meta);

  fetchTitle(video.id).then((title) => {
    const titleEl = meta.querySelector('.video-title');
    if (titleEl) {
      titleEl.textContent = title;
      button.setAttribute('aria-label', `Play video: ${title}`);
    }
    video.title = title;
  });

  return button;
}

function loadVideo(videoId) {
  if (!ytPlayer) return;
  ytPlayer.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;

  const current = videos.find((v) => v.id === videoId);
  if (current && current.title) {
    setNowPlaying(current.title);
  }
}

async function initVideos() {
  if (!videoGrid) return; // Only initialize if element exists
  
  videos.forEach((video) => {
    videoGrid.appendChild(createCard(video));
  });

  if (videos.length) {
    const first = videos[0];
    const title = await fetchTitle(first.id);
    first.title = title;
    setNowPlaying(title);
    loadVideo(first.id);
  }

  videoGrid.addEventListener('click', (event) => {
    const card = event.target.closest('.video-card');
    if (!card) return;
    const videoId = card.dataset.videoId;
    if (!videoId) return;

    loadVideo(videoId);
    card.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
}

initVideos();

function appendChatMessage(text, sender) {
  const container = document.getElementById('ai-messages');
  if (!container) return;

  const message = document.createElement('div');
  message.className = `ai-message ${sender}`;
  message.textContent = text;
  container.appendChild(message);
  container.scrollTop = container.scrollHeight;

  // Track conversation length
  if (sender === 'user' || sender === 'bot') {
    chatState.conversationLength++;
  }
}

// Create message for bot messages (simple bubble)
function createBotMessage(text) {
  const messageWrapper = document.createElement('div');
  messageWrapper.className = 'ai-message-wrapper bot-wrapper';

  // Parse thinking section if present
  const thinkingRegex = /---THINKING---([\s\S]*?)---END THINKING---/;
  const thinkingMatch = text.match(thinkingRegex);
  
  let thinkingText = '';
  let answerText = text;
  
  if (thinkingMatch) {
    thinkingText = thinkingMatch[1].trim();
    // Remove thinking section from answer
    answerText = text.replace(thinkingRegex, '').trim();
  }

  // Create thinking bubble if present
  if (thinkingText) {
    const thinkingBubble = document.createElement('div');
    thinkingBubble.className = 'ai-message-bubble thinking';
    thinkingBubble.innerHTML = `<strong>🤔 Thinking:</strong><br/>${thinkingText.replace(/\n/g, '<br/>')}`;
    messageWrapper.appendChild(thinkingBubble);
  }

  // Create answer bubble
  const bubble = document.createElement('div');
  bubble.className = 'ai-message-bubble bot';
  bubble.innerHTML = answerText;

  messageWrapper.appendChild(bubble);
  return messageWrapper;
}

// Create message for user messages
function createUserMessage(text) {
  const messageWrapper = document.createElement('div');
  messageWrapper.className = 'ai-message-wrapper user-wrapper';
  
  const bubble = document.createElement('div');
  bubble.className = 'ai-message-bubble user';
  bubble.textContent = text;
  
  messageWrapper.appendChild(bubble);
  
  return messageWrapper;
}

// Enhanced append message with proper structure
function appendChatMessageEnhanced(text, sender) {
  const container = document.getElementById('ai-messages');
  if (!container) return;

  let messageElement;
  if (sender === 'bot') {
    messageElement = createBotMessage(text);
  } else {
    messageElement = createUserMessage(text);
  }

  container.appendChild(messageElement);
  container.scrollTop = container.scrollHeight;

  if (sender === 'user' || sender === 'bot') {
    chatState.conversationLength++;
  }
}

// Set user role and notify server
async function setUserRole(role) {
  chatState.userRole = role;
  
  try {
    await fetch('http://localhost:3000/set-role', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ role })
    });
    
    let roleLabel = 'General visitor';
    if (role === 'teacher') roleLabel = 'Educator';
    if (role === 'student') roleLabel = 'Student/Learner';
    if (role === 'collaborator') roleLabel = 'Collaborator';
    
    console.log(`Role set to: ${roleLabel}`);
    
    // Optional: show a brief confirmation
    const roleEl = document.getElementById('ai-user-role');
    if (roleEl) {
      roleEl.textContent = `Role: ${roleLabel}`;
    }
  } catch (error) {
    console.error('Error setting role:', error);
  }
}

// Get conversation info from server
async function getConversationInfo() {
  try {
    const response = await fetch('http://localhost:3000/conversation-info');
    const info = await response.json();
    return info;
  } catch (error) {
    console.error('Error getting conversation info:', error);
    return null;
  }
}

function getFallbackResponse(message) {
  const lower = message.trim().toLowerCase();
  
  // Fallback responses - natural, conversational, human-like
  const patterns = [
    { 
      test: /\b(hi|hello|hey)\b/, 
      reply: `Hey there! Thanks so much for reaching out. I'm really glad you're here. I'm Honore, and I love connecting with people who are interested in education, technology, and how we can make a real difference together. Feel free to ask me anything about my work, my background, or how I can help you. What brings you here today?` 
    },
    { 
      test: /\b(cv|resume|background|experience|qualification)\b/, 
      reply: `Great question! Let me tell you a bit about myself. Right now, I'm teaching STEM subjects at Rukara Model School of Sciences and Mathematics, which is one of Rwanda's leading institutions. At the same time, I'm studying Computer Science and Physics Education at the University of Rwanda - Gisenyi Campus. I'm also working as an ICT trainer with a program called PISQUARE, supported by Edify, where I get to train teachers and help them integrate technology into their teaching. It's a passion of mine to help educators see how technology can actually make their jobs easier and help their students learn better. I've had training from some amazing organizations too, like Florida State University, the Ministry of Education, and Rwanda's Basic Education Board. The coolest part? I get to work at the intersection of education and technology every single day.` 
    },
    { 
      test: /\b(projects?|portfolio|work|build)\b/, 
      reply: `I really enjoy working on projects that solve real problems in education. A lot of what I do involves helping teachers save time and do their jobs better through technology. I've created training programs and resources that have helped over 50 teachers learn digital literacy skills. I work on designing lessons that actually engage students, especially in STEM. And I'm always looking for ways to integrate technology smartly - not just for technology's sake, but because it genuinely helps students understand better and teachers manage their time more effectively. My real focus is making sure that when we use technology in education, it serves the students and teachers, not the other way around. If you want to explore specific projects, check out the Projects page or feel free to ask me more!` 
    },
    { 
      test: /\b(ai|automation|machine learning|ml|robot)\b/, 
      reply: `Oh, this is something I'm passionate about! AI is a powerful tool, but I think we sometimes get swept up in the hype. Here's my honest take: AI isn't magic, and it's definitely not here to replace teachers or educators. Instead, I see it as something that can help us do our work better. For example, AI can help teachers with administrative tasks like grading or planning lessons - the stuff that takes time but doesn't require the human touch. That frees up time for teachers to actually connect with students, which is what really matters in education. The key is understanding how to use these tools responsibly, keeping people at the center, and being clear about what AI can and can't do. Technology is a tool. The human being - the teacher, the educator - that's what transforms lives.` 
    },
    { 
      test: /\b(education|teaching|teacher|student|learning|school)\b/, 
      reply: `Education is my passion, honestly. I believe that good teaching has to combine clear thinking with genuine care for the learner. When I teach or train, I try to explain things in a way that makes sense, I listen to where people are struggling, and I give practical advice they can actually use. I never believe in just throwing information at people without caring about whether they understand. Technology can be a great support to education, but it should never replace the human connection between a teacher and a student. The best learning happens when someone cares about whether you actually get it. That's what I try to bring to everything I do.` 
    },
    { 
      test: /\b(contact|email|phone|reach|connect|collaboration|partner)\b/, 
      reply: `I'd love to connect with you! If you want to chat directly with me, you can reach out by email at tuyishimehonore63@gmail.com or call me at +250 791 684 429. I'm always interested in talking about teacher training, education technology, or just ideas about how we can improve learning. I'm open to collaborations on projects that make a real impact, whether that's training teachers, developing educational resources, or thinking through how technology can serve education better. You can also find me on social media - links are in the footer. The important thing is that I'm here and I want to hear from you!` 
    },
    { 
      test: /\b(help|guide|how|what|why|explain|learn)\b/, 
      reply: `I'm here to help, and I mean that genuinely. When someone asks me a question, I try to really listen to what they're actually asking underneath the words. Then I think through it carefully, explain my reasoning, and give you something practical you can actually use. I always try to ground what I say in real experience and evidence, not just opinions. If you're trying to accomplish something or figure something out, tell me what's going on. What's the real challenge? The more context you give me, the better I can help. And if you have any documents or materials you want me to look at, don't hesitate to share.` 
    },
  ];

  for (const entry of patterns) {
    if (entry.test.test(lower)) return entry.reply;
  }

  return `I appreciate the question, and I want to give you a thoughtful answer. Let me understand what you're really asking for. The best conversations happen when we're clear about what we're trying to figure out or accomplish. Are you asking about my background and experience? My work in education? How technology and teaching intersect? Or maybe something else entirely? Tell me more about what you're curious about, and I'll do my best to give you a real, honest answer. If you want to share any documents or materials, I can take a look at those too and use them to give you more specific help.`;
}

// HONORE'S COMPLETE BACKGROUND CONTEXT
const HONORE_CONTEXT = `
YOU ARE TUYISHIME HONORE

PERSONAL INFORMATION:
- Full Name: TUYISHIME Honore
- Date of Birth: 28th February 2002 (Age 22)
- Gender: Male
- Nationality: Rwandan
- Location: Eastern Province, Nyagatare District, Matimba Sector, Kagitumba Cell, Rwanda
- Phone: +250 791 684 429
- Email: tuyishimehonore63@gmail.com
- Family: Father - KWITONDA Gaspard, Mother - MUKANKUNDIYE Philomene

CURRENT ROLES (2024-Present):
1. Teacher at Rukara Model School of Sciences and Mathematics (Sept 2024-Present)
   - Teaching STEM subjects to secondary students
   - Integrating ICT and educational technology into classroom practice
   - Mentoring students in critical thinking
   - Designing assessments and providing feedback
   - Contributing to school professional development

2. ICT Trainer with PISQUARE/Edify (Nov 2025-Present)
   - Training 100+ primary school teachers in ICT integration
   - Teaching practical technology tools (Google Classroom, MS Teams, Kahoot, etc.)
   - Designing and delivering ICT training workshops
   - Supporting teachers in integrating technology into curriculum
   - Building capacity for sustainable digital education

3. Student at ULK (2024-Present)
   - Bachelor of Education in Computer Science and Physics (CSP)
   - Gisenyi Campus
   - Combining technical computer science with physics education methodology

EDUCATION QUALIFICATIONS:
- TTC De La Salle: Primary Teaching Residency Program (2023-2024) - Certificate of Completion
  Focus: ICT Integration, Teaching Methodologies, Advanced English
- TTC Matimba: A2 Diploma in Science & Mathematics Education (2020-2023)
  Focus: Science and mathematics pedagogy
- GS Kagitumba: O-Level Certificate (2017-2019)
- GS Kagitumba: Primary Certificate (2011-2016)

PREVIOUS TEACHING EXPERIENCE:
- Resident Teacher at GS Gacurabwenge (1 year)
  Taught: Mathematics, Science & Technology, Languages, Sports, Social Studies
- Teaching Intern at GS Kagitumba (Oct-Dec 2022)

PROFESSIONAL CERTIFICATIONS & TRAINING:
- EdTech Integration Pilot Training (REB & World Bank)
- CPD-ITMS: ICT in Teaching & Pedagogy (UR Centre of Excellence)
- PISQUARE Trainer Certification (Edify)
- Microsoft Online Course (Microsoft)
- MCE Training (Teacher College)
- Primary Teaching Residency Program Pilot (Florida State University, Bridge2Rwanda, IEE, Rainwater Foundation)
- CPD Items Development Training (University of Rwanda & REB)
- Artificial Intelligence & Digital Education Training
- Microsoft Certified Educator
- SkillsBuild Completion & AI Literacy Credential

TECHNICAL SKILLS:
- Web Development: HTML5, CSS3, JavaScript, PHP, MySQL, Laravel, Bootstrap, Joomla, WordPress
- Programming: Scratch, Turtle Art, jQuery
- Educational Platforms: Google Classroom, Microsoft Teams, Kahoot, Quizlet, Khan Academy, GeoGebra, EduPuzzle, Flip Grid, Mentimeter, Plickers
- Office Tools: MS Word, Excel, PowerPoint, Access, Google Docs/Sheets/Slides
- Media: Video production, image design, certificate design, AI tools for content creation

LANGUAGES:
- English: Excellent (Speaking, Listening, Reading, Writing)
- Kinyarwanda: Excellent (Speaking, Listening, Reading, Writing)
- French: Good (Speaking, Listening, Reading, Writing)

MISSION & VALUES:
- Primary Mission: To transform Rwanda's education system by empowering teachers and learners with digital skills, innovative approaches, and modern technologies
- Core Belief: Bridging the gap between traditional teaching methods and technology-enabled education
- Teaching Philosophy: Good teaching combines clear thinking with genuine care for the learner; never just throwing information without caring if they understand
- Technology Philosophy: Technology should support education, not replace human connection; it serves students and teachers, not the other way around
- Passion: Education technology, teaching methodology, helping teachers integrate tech into classrooms

SPIRITUAL/MINISTRY:
- Currently studying theology at two institutions:
  1. **Promise Bible Centre** (2024-2025 - Present) - 2-Year Program in Kinyarwanda Version Theology with 34 comprehensive courses including:
     - Complete Old Testament: Pentateuch, History Books, Wisdom Literature, Major/Minor Prophets
     - Complete New Testament: Four Gospels, Acts, Paul's Epistles, Pastoral Letters, Revelation
     - Theology Courses: Christology, Soteriology, Pneumatology, Eschatology, Pneumatology
     - Practical Ministry: Homiletics, Evangelism, Church History, Reconciliation, Spiritual Formation
  2. **Africa Multination for Christ College** (2026 - Present) - Foundational Certificate with 16 core courses:
     - Bible Synthesis, Prayer, Doctrinal Foundations, Soteriology, Practical Deliverance
     - Church History, Effective Preaching, Counseling, Laws of Leadership, Kingdom of God
     - Holy Spirit Studies, Life and Teachings of Christ, Child Evangelism, Character of God
     - Church Growth, Guidance Rules and Policy
- Biblical Foundation: Matthew 28:19 (Great Commission) & Acts 1:8 (Witness to the ends of the earth)
- Ministry Focus: Discipleship, preaching, youth education, community spiritual empowerment
- YouTube Channel: Ministry content in Kinyarwanda (ESE IMIRIMO, biblical teaching, etc.)

PROFESSIONAL REFERENCES:
1. Dr. Barnabas Muyengwa - Principal, Rukara Model School (Ask about: Teaching performance, STEM education) +250 792 045 452
2. Erick Iyamuremyi - Head PISQUARE & DOS, Rukara (Ask about: ICT training programs, digital literacy) +250 788 244 491
3. Br. Ferdinand Biziyaremye - Coordinator TTC De La Salle Primary Teaching Residency (Ask about: Teaching methodology, pedagogy) +250 789 139 618
4. Isaie Murwanyi - Principal TTC Matimba (Ask about: Teacher training credentials) +250 785 368 119

PROJECTS & ACHIEVEMENTS:
- Digital Lesson Plan: Web app for helping teachers build, organize, and share lesson plans
- ICT Education YouTube Channel: Tutorials, tips, and resources for integrating digital tools
- Trained 100+ primary school teachers in ICT integration and digital literacy
- Facilitated CPD initiatives at Rukara Model School

IMPORTANT INSTRUCTIONS FOR RESPONDING:
1. SPEAK AS HONORE - Use "I" and speak directly, not as an AI assistant
2. ALWAYS SHOW YOUR THINKING - Format: ---THINKING--- (reflect on what they're asking and what from your background applies) ---END THINKING--- then answer
3. REFERENCE REAL EXPERIENCE - When asked about teaching, mention Rukara specifically. When asked about training, mention PISQUARE and 100+ teachers. Use concrete examples.
4. BE SPECIFIC - Don't give generic answers. Use examples like: "At Rukara I found that when students use tools like Scratch or GeoGebra, they understand abstract concepts better"
5. SPEAK NATURALLY - Use natural flowing paragraphs, warm and genuine tone, like talking to someone in person
6. STAY TRUE - Your mission is bridging traditional and tech-enabled teaching. Your passion is helping teachers grow. Use real examples from your work.
7. SHOW REASONING - Demonstrate you're thinking about their question, considering your actual experience, and providing grounded answers
`;

// OpenAI API Key - User will set this
let OPENAI_API_KEY = '';

// Function to set the OpenAI API key (call this from console or put in code)
function setOpenAIKey(apiKey) {
  OPENAI_API_KEY = apiKey;
  console.log('✓ OpenAI API key set successfully');
  console.log('🟢 Chat will now use real AI responses with thinking bubbles');
}

// Show startup message
console.log('%c🤖 HONORE AI CHAT READY', 'color: #228b22; font-size: 14px; font-weight: bold;');
console.log('%c📝 To enable AI responses: Open console and paste:\nsetOpenAIKey("sk-proj-YOUR-KEY-HERE")', 'color: #FF6B35; font-size: 12px;');
console.log('%cThen chat will show real AI responses with thinking bubbles! 🧠', 'color: #4a584a; font-size: 12px;');

async function getChatResponse(message) {
  try {
    // If no API key, use fallback
    if (!OPENAI_API_KEY) {
      console.warn('⚠️ OpenAI API key not set. Using fallback responses.');
      console.log('To use OpenAI: Call setOpenAIKey("sk-proj-YOUR-KEY-HERE") in console');
      return getFallbackResponse(message);
    }

    // Prepare conversation history for context
    const conversationMessages = [];
    if (chatState.conversationLength > 0) {
      // Add last few messages for context
      const container = document.getElementById('ai-messages');
      if (container) {
        const userMessages = Array.from(container.querySelectorAll('.user-wrapper')).slice(-3);
        userMessages.forEach(msg => {
          const text = msg.querySelector('.ai-message-bubble')?.textContent || '';
          if (text) conversationMessages.push({ role: 'user', content: text });
        });
      }
    }

    // Call OpenAI API directly from browser
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: HONORE_CONTEXT
          },
          ...conversationMessages,
          {
            role: 'user',
            content: message
          }
        ],
        temperature: 0.6,
        max_tokens: 600
      })
    });

    if (!response.ok) {
      const error = await response.json();
      console.error('❌ OpenAI API Error:', error);
      throw new Error(`OpenAI API Error: ${error.error?.message || 'Unknown error'}`);
    }

    const data = await response.json();
    const aiResponse = data.choices[0]?.message?.content;
    
    if (!aiResponse) {
      console.warn('⚠️ No response content from OpenAI');
      return getFallbackResponse(message);
    }

    console.log('✅ OpenAI response received');
    return aiResponse;

  } catch (error) {
    console.error('❌ AI service error:', error.message);
    console.log('📝 Using fallback response');
    return getFallbackResponse(message);
  }
}

function initChat() {
  const widget = document.getElementById('ai-widget');
  const toggle = document.getElementById('ai-toggle');
  const closeBtn = document.getElementById('ai-close');
  const form = document.getElementById('ai-form');
  const input = document.getElementById('ai-input');

  if (!widget || !form || !input || !toggle) return;

  // Start collapsed; show greeting when the user opens the chat.
  let firstOpen = true;

  function openWidget() {
    widget.classList.add('open');
    widget.classList.remove('collapsed');
    toggle.setAttribute('aria-expanded', 'true');
    input.focus();

    if (firstOpen) {
      appendChatMessageEnhanced('Hello! I\'m Honore. I really appreciate you reaching out and taking the time to connect. I\'m here to help, share ideas, and support you in any way I can. How can I assist you today?', 'bot');
      firstOpen = false;
    }
  }

  function closeWidget() {
    widget.classList.remove('open');
    widget.classList.add('collapsed');
    toggle.setAttribute('aria-expanded', 'false');
  }

  // Make toggle button use a small avatar when collapsed
  if (!toggle.querySelector('.ai-avatar-mini')) {
    const avatar = document.createElement('img');
    avatar.src = 'profile.jpg';
    avatar.alt = 'AI chat';
    avatar.className = 'ai-avatar-mini';
    avatar.role = 'button';
    avatar.tabIndex = 0;

    const text = document.createElement('span');
    text.className = 'ai-toggle-text';
    text.textContent = 'Chat with Honore';

    toggle.textContent = '';
    toggle.style.flexDirection = 'column';
    toggle.appendChild(avatar);
    toggle.appendChild(text);

    // Make avatar independently clickable
    avatar.addEventListener('click', (e) => {
      e.stopPropagation();
      openWidget();
    });
  }

  // Keep widget collapsed on load; expand only when the user clicks.
  toggle.addEventListener('click', () => {
    if (widget.classList.contains('open')) {
      closeWidget();
    } else {
      openWidget();
    }
  });

  closeBtn?.addEventListener('click', closeWidget);

  // Make header profile image clickable to open chat
  const headerAvatar = document.querySelector('.ai-avatar');
  if (headerAvatar) {
    headerAvatar.style.cursor = 'pointer';
    headerAvatar.addEventListener('click', openWidget);
  }

  // Role selector removed - not needed

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const value = input.value.trim();
    if (!value) return;

    appendChatMessageEnhanced(value, 'user');
    input.value = '';
    input.disabled = true;

    try {
      const response = await getChatResponse(value);
      appendChatMessageEnhanced(response, 'bot');
    } catch (error) {
      appendChatMessageEnhanced('Sorry, there was an error. Please try again.', 'bot');
    } finally {
      input.disabled = false;
      input.focus();
    }
  });

  const fileInput = document.getElementById('ai-file');
  const fileStatus = document.getElementById('ai-file-status');

  if (fileInput) {
    fileInput.addEventListener('change', async () => {
      const file = fileInput.files?.[0];
      if (!file) return;

      fileStatus.textContent = 'Uploading...';

      const formData = new FormData();
      formData.append('document', file);

      try {
        const resp = await fetch('http://localhost:3000/upload', {
          method: 'POST',
          body: formData
        });

        const result = await resp.json();
        if (resp.ok) {
          chatState.uploadedDocuments = result.documents || [];
          fileStatus.textContent = `✓ "${file.name}" uploaded. I'll reference it in my answers.`;
          
          // Optional: notify user in chat
          appendChatMessageEnhanced(`I've loaded your document: "${file.name}". Feel free to ask me questions about it!`, 'bot');
        } else {
          fileStatus.textContent = result.error || 'Upload failed.';
        }
      } catch (err) {
        fileStatus.textContent = 'Upload failed (network error).';
      }

      // Reset file input
      fileInput.value = '';
    });
  }
}

initChat();


initChat();

const quotes = [
  { text: "Education is the most powerful weapon which you can use to change the world.", author: "Nelson Mandela" },
  { text: "Technology will not replace great teachers, but technology in the hands of great teachers can be transformational.", author: "George Couros" },
  { text: "The future of education is not in the classroom; it is in the connections we build and the digital tools we harness.", author: "Tuyishime Honore" },
  { text: "When we teach computers to learn, we must also teach learners to think.", author: "Unknown" },
  { text: "Every student can learn, just not on the same day, or the same way.", author: "George Evans" },
  { text: "The best way to predict the future is to create it.", author: "Peter Drucker" },
  { text: "Learning is not a spectator sport.", author: "D. Blocher" },
  { text: "Tell me and I forget. Teach me and I remember. Involve me and I learn.", author: "Benjamin Franklin" },
  { text: "Digital learning is not about technology; it’s about empowering learners.", author: "Unknown" },
  { text: "Coding is today’s language of creativity.", author: "Unknown" },
  { text: "The important thing is not to stop questioning. Curiosity has its own reason for existing.", author: "Albert Einstein" },
  { text: "Teaching is the one profession that creates all other professions.", author: "Unknown" },
  { text: "You don’t have to be great to start, but you have to start to be great.", author: "Zig Ziglar" },
  { text: "The role of a teacher is to create the conditions for invention rather than provide ready-made knowledge.", author: "Seymour Papert" },
  { text: "Access to technology is not enough. It must be backed by good teaching.", author: "Unknown" },
  { text: "A child’s mind is not a vessel to be filled but a fire to be kindled.", author: "Dorothy Butler" },
  { text: "Learning is not a place; it is a process.", author: "G. K. Chesterton" },
  { text: "The function of education is to teach one to think intensively and to think critically.", author: "Martin Luther King Jr." },
  { text: "When learning becomes a habit, success becomes a tradition.", author: "Unknown" },
  { text: "Every problem is a gift—without problems we would not grow.", author: "Anthony Robbins" },
  { text: "Digital skills are the currency of the 21st century.", author: "Unknown" },
  { text: "Curiosity is the wick in the candle of learning.", author: "William Arthur Ward" },
  { text: "Great teachers empathize with children, respect them, and believe that each one has something special that can be built upon.", author: "Ann Lieberman" },
  { text: "Education is the passport to the future, for tomorrow belongs to those who prepare for it today.", author: "Malcolm X" },
  { text: "Students don’t care how much you know until they know how much you care.", author: "John C. Maxwell" },
  { text: "Technology alone won’t fix education, but well-used technology can open doors.", author: "Unknown" },
  { text: "Learning is a treasure that will follow its owner everywhere.", author: "Chinese Proverb" },
  { text: "The greatest sign of success for a teacher is to be able to say, 'The children are now working as if I did not exist.'", author: "Maria Montessori" },
  { text: "The only way to do great work is to love what you do.", author: "Steve Jobs" },
  { text: "A teacher affects eternity; he can never tell where his influence stops.", author: "Henry Adams" },
  { text: "The more that you read, the more things you will know. The more that you learn, the more places you’ll go.", author: "Dr. Seuss" },
  { text: "Learning never exhausts the mind.", author: "Leonardo da Vinci" },
  { text: "To teach is to learn twice.", author: "Joseph Joubert" },
  { text: "Good teaching is more a giving of right questions than a giving of right answers.", author: "Josef Albers" },
  { text: "Every child deserves a champion: an adult who will never give up on them.", author: "Rita Pierson" },
  { text: "Education is not preparation for life; education is life itself.", author: "John Dewey" },
  { text: "The beautiful thing about learning is that no one can take it away from you.", author: "B.B. King" },
  { text: "Innovation is the ability to see change as an opportunity, not a threat.", author: "Steve Jobs" },
  { text: "A great teacher takes a hand, opens a mind, and touches a heart.", author: "Unknown" },
  { text: "Programming today is a race between software engineers trying to build bigger and better idiot-proof programs, and the Universe trying to build bigger and better idiots.", author: "Rick Cook" },
  { text: "The most valuable resource that all teachers have is each other. Without collaboration our growth is limited to our own perspectives.", author: "Robert John Meehan" },
  { text: "Success is the sum of small efforts repeated day in and day out.", author: "Robert Collier" },
  { text: "The greatest learning happens outside the classroom when we apply what we know.", author: "Unknown" },
  { text: "Technology is best when it brings people together.", author: "Matt Mullenweg" },
  { text: "Learning is the only thing the mind never exhausts, never fears, and never regrets.", author: "Leonardo da Vinci" },
  { text: "The purpose of education is to replace an empty mind with an open one.", author: "Malcolm Forbes" },
  { text: "Excellence is not a destination; it is a continuous journey that never ends.", author: "Brian Tracy" },
  { text: "You don’t learn to walk by following rules. You learn by doing, and by falling over.", author: "Richard Branson" },
  { text: "If you can dream it, you can do it.", author: "Walt Disney" },
  { text: "Learning is a lifelong process, and the best teachers are the ones who keep learning.", author: "Unknown" },
];

const quoteText = document.getElementById('rotator-text');
const quoteAuthor = document.getElementById('rotator-author');
const quoteCounter = document.getElementById('quote-counter');
const prevBtn = document.getElementById('quote-prev');
const nextBtn = document.getElementById('quote-next');

let quoteIndex = 0;

function renderQuote(index) {  if (!quoteText || !quoteAuthor || !quoteCounter) return;  const quote = quotes[index];
  quoteText.textContent = `“${quote.text}”`;
  quoteAuthor.textContent = `— ${quote.author}`;
  quoteCounter.textContent = `${index + 1} / ${quotes.length}`;
}

function showNextQuote() {
  quoteIndex = (quoteIndex + 1) % quotes.length;
  renderQuote(quoteIndex);
}

function showPrevQuote() {
  quoteIndex = (quoteIndex - 1 + quotes.length) % quotes.length;
  renderQuote(quoteIndex);
}

if (prevBtn) prevBtn.addEventListener('click', showPrevQuote);
if (nextBtn) nextBtn.addEventListener('click', showNextQuote);

if (quoteText) renderQuote(0);